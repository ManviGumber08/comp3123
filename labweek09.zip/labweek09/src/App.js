import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <div className="container">
        <img 
          src="https://upload.wikimedia.org/wikipedia/commons/a/a7/React-icon.svg" 
          alt="React Logo" 
          className="logo"
        />
        <h1>Welcome to Fullstack Development - I</h1>
        <h2>React JS Programming Week09 Lab exercise</h2>
        <p>101412099</p>
        <p>Manvi Gumber </p>
        <p>George Brown College, Toronto</p>
      </div>
    </div>
  );
}

export default App;
