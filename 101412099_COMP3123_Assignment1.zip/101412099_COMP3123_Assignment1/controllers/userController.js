const { validationResult } = require('express-validator');
const User = require('../models/user');

// Signup controller
exports.signup = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { username, email, password } = req.body;

    try {
        const newUser = new User({
            username,
            email,
            password, // Consider hashing the password before saving
            created_at: new Date(),
            updated_at: new Date()
        });

        await newUser.save();
        res.status(201).json({
            message: 'User created successfully.',
            user_id: newUser._id
        });
    } catch (error) {
        console.error('Error during user creation:', error);
        res.status(500).json({ error: 'User creation failed', details: error.message });
    }
};

// Login controller
exports.login = async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email }); // Find user by email

        // Check if user exists and if password matches
        if (!user || user.password !== password) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Login successful
        res.status(200).json({ message: 'Login successful.' });
    } catch (error) {
        console.error('Login failed:', error);
        res.status(500).json({ error: 'Login failed', details: error.message });
    }
};
