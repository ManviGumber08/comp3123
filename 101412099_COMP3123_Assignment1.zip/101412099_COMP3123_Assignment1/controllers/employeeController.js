const Employee = require('../models/employee');

// Create employee controller
exports.createEmployee = async (req, res) => {
    const { first_name, last_name, position, department, email, salary, date_of_joining } = req.body;

    try {
        const newEmployee = new Employee({
            first_name,
            last_name,
            position,
            department,
            email,
            salary,
            date_of_joining
        });

        await newEmployee.save();
        res.status(201).json({
            message: 'Employee created successfully.',
            employee_id: newEmployee._id,
        });
    } catch (error) {
        console.error('Error during employee creation:', error);
        res.status(500).json({ error: 'Employee creation failed', details: error.message });
    }
};

// Get all employees controller
exports.getAllEmployees = async (req, res) => {
    try {
        const employees = await Employee.find();
        res.status(200).json(employees);
    } catch (error) {
        console.error('Error fetching employees:', error);
        res.status(500).json({ error: 'Failed to fetch employees', details: error.message });
    }
};

// Get single employee by ID controller
exports.getEmployeeById = async (req, res) => {
    const { id } = req.params; // Get employee ID from the URL

    try {
        const employee = await Employee.findById(id);
        if (!employee) {
            return res.status(404).json({ error: 'Employee not found' });
        }

        res.status(200).json(employee);
    } catch (error) {
        console.error('Error fetching employee:', error);
        res.status(500).json({ error: 'Failed to fetch employee', details: error.message });
    }
};

// Update employee controller
exports.updateEmployee = async (req, res) => {
    const { id } = req.params; // Get employee ID from the URL
    const updatedData = req.body; // Get updated data from request body

    try {
        // Find the employee by ID and update their details
        const updatedEmployee = await Employee.findByIdAndUpdate(id, updatedData, { new: true });

        if (!updatedEmployee) {
            return res.status(404).json({ error: 'Employee not found' });
        }

        res.status(200).json({
            message: 'Employee updated successfully',
            employee: updatedEmployee
        });
    } catch (error) {
        console.error('Error updating employee:', error);
        res.status(500).json({
            error: 'Employee update failed',
            details: error.message
        });
    }
};

// Delete employee controller
exports.deleteEmployee = async (req, res) => {
    const { id } = req.params; // Get employee ID from URL

    try {
        const employee = await Employee.findByIdAndDelete(id); // Find employee by ID and delete

        if (!employee) {
            return res.status(404).json({ error: 'Employee not found' });
        }

        res.status(200).json({ message: 'Employee deleted successfully.' });
    } catch (error) {
        console.error('Error deleting employee:', error);
        res.status(500).json({ error: 'Failed to delete employee', details: error.message });
    }
};
