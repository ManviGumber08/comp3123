const express = require('express');
const mongoose = require('mongoose');
const userRoutes = require('./routes/user'); // Import user routes
const employeeRoutes = require('./routes/employee'); // Import employee routes

const app = express();

// MongoDB connection URI
const uri = 'mongodb+srv://101412099:George45678!@cluster0.6ie9d.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

mongoose.connect(uri)
    .then(() => console.log('MongoDB connected successfully'))
    .catch(err => console.log('MongoDB connection error:', err));

// Middleware to parse JSON requests
app.use(express.json());

// Routes
app.use('/api/v1/user', userRoutes); // Mount user routes
app.use('/api/v1/emp', employeeRoutes); // Mount employee routes

// Start the server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
