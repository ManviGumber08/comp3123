const express = require('express');
const router = express.Router();
const employeeController = require('../controllers/employeeController'); // Import the employee controller

// Create a new employee
router.post('/employees', employeeController.createEmployee);

// Get all employees
router.get('/employees', employeeController.getAllEmployees);

// Get a single employee by ID
router.get('/employees/:id', employeeController.getEmployeeById);

// Update an existing employee
router.put('/employees/:id', employeeController.updateEmployee);

// Delete an employee
router.delete('/employees/:id', employeeController.deleteEmployee); // Add the DELETE route

// Export the router
module.exports = router;
