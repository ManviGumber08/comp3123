// src/components/Form.js

import React from 'react';
import TextInput from './textInput';
import SelectInput from './selectInput';
import CheckboxInput from './CheckboxInput';

function Form({ formData, onInputChange, onSubmit }) {
  const provinces = [
    "Alberta", "British Columbia", "Manitoba", "New Brunswick", 
    "Newfoundland and Labrador", "Nova Scotia", "Ontario", 
    "Prince Edward Island", "Quebec", "Saskatchewan"
  ];

  return (
    <form onSubmit={onSubmit}>
      <TextInput label="Email" name="email" value={formData.email} onChange={onInputChange} />
      <TextInput label="Full Name" name="fullName" value={formData.fullName} onChange={onInputChange} />
      <TextInput label="Address" name="address" value={formData.address} onChange={onInputChange} />
      <TextInput label="Address 2" name="address2" value={formData.address2} onChange={onInputChange} />
      <TextInput label="City" name="city" value={formData.city} onChange={onInputChange} />
      <SelectInput label="Province" name="province" options={provinces} value={formData.province} onChange={onInputChange} />
      <TextInput label="Postal Code" name="postalCode" value={formData.postalCode} onChange={onInputChange} />
      <CheckboxInput label="Agree Terms & Condition?" name="terms" checked={formData.terms} onChange={onInputChange} />
      <button type="submit">Submit</button>
    </form>
  );
}

export default Form;
