import React from 'react';

function CheckboxInput({ label, name, checked, onChange }) {
  return (
    <div>
      <label>
        <input
          type="checkbox"
          name={name}
          checked={checked}
          onChange={(e) => onChange(name, e.target.checked)}
        />
        {label}
      </label>
    </div>
  );
}

export default CheckboxInput;
