// src/components/SelectInput.js

import React from 'react';

function SelectInput({ label, name, options, value, onChange }) {
  return (
    <div>
      <label>{label}</label>
      <select name={name} value={value} onChange={(e) => onChange(name, e.target.value)}>
        <option value="">Choose...</option>
        {options.map((option, index) => (
          <option key={index} value={option}>{option}</option>
        ))}
      </select>
    </div>
  );
}

export default SelectInput;
