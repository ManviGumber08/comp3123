import { useState } from 'react';
import Form from './components/form'; 
import './App.css';

function App() {
  const [formData, setFormData] = useState({
    email: '',
    fullName: '',
    address: '',
    address2: '',
    city: '',
    province: '',
    postalCode: '',
    terms: false,
  });

  const handleInputChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`
      Email: ${formData.email}
      Full Name: ${formData.fullName}
      Address: ${formData.address}
      Address 2: ${formData.address2}
      City: ${formData.city}
      Province: ${formData.province}
      Postal Code: ${formData.postalCode}
    `);
  };

  return (
    <div className="App">
      <h1>Data Entry Form</h1>
      <Form formData={formData} onInputChange={handleInputChange} onSubmit={handleSubmit} />
    </div>
  );
}

export default App;
